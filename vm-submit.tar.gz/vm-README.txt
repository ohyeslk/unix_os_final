Documentation for Kernel Assignment 3
=====================================

+-------------+
| BUILD & RUN |
+-------------+

Comments: Comments: Please make clean before make.
	And then ./weenix -n to run the operating system.
	After user space shell invoked, the test in part B and part C could be tested by typing command in the user space shell.
	Because we have finished the part D,user could update "Config.mk" to have DYNAMIC=1, recompile and restart weenix.

+------+
| SKIP |
+------+

none

+---------+
| GRADING |
+---------+

(A.1) In mm/pframe.c:
    (a) In pframe_pin(): 1 out of 1 pts
    (b) In pframe_unpin(): 1 out of 1 pts

(A.2) In In vm/mmap.c:
    (a) In do_mmap():: 2 out of 2 pts
    (b) In do_munmap(): 2 out of 2 pts
    
(A.3) In vm/vmmap.c:
    (a) In vmmap_destroy(): 2 out of 2 pts
    (b) In vmmap_insert(): 2 out of 2 pts
    (c) In vmmap_find_range(): 2 out of 2 pts
    (d) In vmmap_lookup(): 1 out of 1 pts
    (e) In vmmap_is_range_empty(): 1 out of 1 pts
    (f) In vmmap_map(): 7 out of 7 pts

(A.4) In vm/anon.c:
    (a) In anon_init(): 1 out of 1 pts
    (b) In anon_ref(): 1 out of 1 pts
    (c) In anon_put(): 1 out of 1 pts
    (d) In anon_fillpage(): 1 out of 1 pts

(A.5) In fs/vnode.c:
    (a) In special_file_mmap(): 2 out of 2 pts

(A.6) In vm/shadow.c:
    (a) In shadow_init(): 1 out of 1 pts
    (b) In shadow_ref(): 1 out of 1 pts
    (c) In shadow_put(): 1 out of 1 pts
    (d) In shadow_fillpage(): 2 out of 2 pts

(A.7) In proc/fork.c:
    (a) In do_fork(): 6 out of 6 pts

(A.8) In proc/kthread.c:
    (a) In kthread_clone(): 2 out of 2 pts

(B.1) /usr/bin/hello (3 out of 3 pts)
(B.2) /bin/uname -a (3 out of 3 pts)
(B.3) /usr/bin/args ab cde fghi j (3 out of 3 pts)
(B.4) /usr/bin/fork-and-wait (5 out of 5 pts)

(C.1) /usr/bin/segfault (5 out of 5 pts)
(C.2) /usr/bin/vfstest (6 out of 6 pts)
(C.3) /usr/bin/memtest (6 out of 6 pts)
(C.4) /usr/bin/eatmem (6 out of 6 pts)
(C.5) /usr/bin/forkbomb (6 out of 6 pts)
(C.6) /usr/bin/stress (6 out of 6 pts)

(D.1) /usr/bin/vfstest (1 out of 1 pt)
(D.2) /usr/bin/memtest (1 out of 1 pt)
(D.3) /usr/bin/eatmem (1 out of 1 pt)
(D.4) /usr/bin/forkbomb (1 out of 1 pt)
(D.5) /usr/bin/stress (1 out of 1 pt)

(E) Self-checks: (10 out of 10 pts)
    Comments: none

Missing required section(s) in README file (vm-README.txt): nothing is missed
Submitted binary file : No
Submitted extra (unmodified) file : No
Wrong file location in submission : No
Use dbg_print(...) instead of dbg(DBG_PRINT, ...) : No, We have used dbg(DBG_PRINT, ...)
Not properly indentify which dbg() printout is for which item in the grading guidelines : have identified
Cannot compile : compile fine
Compiler warnings : No warnings
"make clean" : works fine
Useless KASSERT : None
Insufficient/Confusing dbg : None
Kernel panic : No
Cannot halt kernel cleanly : Kernel halts cleanly


+------+
| BUGS |
+------+

Comments: no bugs

+---------------------------+
| CONTRIBUTION FROM MEMBERS |
+---------------------------+

Everyone has contributed equally.

Team members:
Jianan Xing  25%
Kai Lu       25%
Priyanka Sulugodu Prakash Murthy  25%
Mengxian Li  25%

+-------+
| OTHER |
+-------+

Special DBG setting in Config.mk for certain tests: none
Comments on deviation from spec (you will still lose points, but it's better to let the grader know): none
General comments on design decisions: none

